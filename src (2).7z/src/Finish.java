import java.awt.*;
import javax.swing.*;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Finish extends JComponent {
    private Image finish;

    public Finish() {
        try {
            finish = ImageIO.read(new File("C:\\Users\\Joost\\IdeaProjects\\TestField2\\src\\tiles\\end.png"));
        } catch (IOException e) {
            System.out.println("error");
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        g.drawImage(finish,0,0,this);
    }
}