import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import  java.awt.event.KeyEvent;
import  java.awt.event.KeyListener;

class Move extends Frame implements KeyListener {

    public int rows = 0; // the row in which the player is located
    public int columns = 0; // the column in which the player is located

    public void keyTyped(KeyEvent e) {
        //no code here
        }

    /**
     * @param e
     * the key which is pressed
     * you can use the arrow keys to move around
     */
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode(); // number for a certain KeyEvent

        switch (keyCode) {

            //when left key is pressed
            case KeyEvent.VK_LEFT:
                if (columns > 0 && grid[rows][columns-1].equals("g")) {
                    grid[rows][columns] = "g";
                    columns--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else if (columns > 0 && grid[rows][columns-1].equals("k100")) {
                    grid[rows][columns] = "g";
                    columns--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a key");
                    keyValue = 100;
                    drawGrid();
                } else if (columns > 0 && grid[rows][columns-1].equals("k200")) {
                    grid[rows][columns] = "g";
                    columns--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a scissor");
                    keyValue = 200;
                    drawGrid();
                } else if (columns > 0 && grid[rows][columns-1].equals("k300")) {
                    grid[rows][columns] = "g";
                    columns--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a chainsaw");
                    keyValue = 300;
                    drawGrid();
                } else if (columns > 0 && grid[rows][columns-1].equals("b100") && keyValue != 100) {
                    JOptionPane.showMessageDialog(field, "you need a key to open this barricade");
                } else if (columns > 0 && grid[rows][columns-1].equals("b200") && keyValue != 200) {
                    JOptionPane.showMessageDialog(field, "you need a scissor to cut this bush");
                } else if (columns > 0 && grid[rows][columns-1].equals("b300") && keyValue != 300) {
                    JOptionPane.showMessageDialog(field, "you need a chainsaw to break this stump");
                } else if (columns > 0 && grid[rows][columns-1].equals("b100") || columns > 0 && grid[rows][columns-1].equals("b200") || columns > 0 && grid[rows][columns-1].equals("b300")) {
                    grid[rows][columns] = "g";
                    columns--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else {
                    System.out.println("you can't go there");
                }
                break;

                //when right key is pressed
            case KeyEvent.VK_RIGHT:
                if (columns < 9 && grid[rows][columns+1].equals("g")) {
                    grid[rows][columns] = "g";
                    columns++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else if (columns < 9 && grid[rows][columns+1].equals("f")) {
                    grid[rows][columns] = "g";
                    columns++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                    JOptionPane.showMessageDialog(field, "you win!");
                } else if (columns < 9 && grid[rows][columns+1].equals("k100")) {
                    grid[rows][columns] = "g";
                    columns++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a key");
                    keyValue = 100;
                    drawGrid();
                } else if (columns < 9 && grid[rows][columns+1].equals("k200")) {
                    grid[rows][columns] = "g";
                    columns++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a scissor");
                    keyValue = 200;
                    drawGrid();
                } else if (columns < 9 && grid[rows][columns+1].equals("k300")) {
                    grid[rows][columns] = "g";
                    columns++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a chainsaw");
                    keyValue = 300;
                    drawGrid();
                } else if (columns < 9 && grid[rows][columns+1].equals("b100") && keyValue != 100) {
                    JOptionPane.showMessageDialog(field, "you need a key to open this barricade");
                } else if (columns < 9 && grid[rows][columns+1].equals("b200") && keyValue != 200) {
                    JOptionPane.showMessageDialog(field, "you need a scissor to cut this bush");
                } else if (columns < 9 && grid[rows][columns+1].equals("b300") && keyValue != 300) {
                    JOptionPane.showMessageDialog(field, "you need a chainsaw to break this stump");
                } else if (columns < 9 && grid[rows][columns+1].equals("b100") || columns < 9 && grid[rows][columns+1].equals("b200") || columns < 9 && grid[rows][columns+1].equals("b300")) {
                    grid[rows][columns] = "g";
                    columns++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else {
                    System.out.println("you can't go there");
                }
                break;

                //when up key is pressed
            case KeyEvent.VK_UP:
                if (rows > 0 && grid[rows-1][columns].equals("g")) {
                    grid[rows][columns] = "g";
                    rows--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else if (rows > 0 && grid[rows-1][columns].equals("k100")) {
                    grid[rows][columns] = "g";
                    rows--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a key");
                    keyValue = 100;
                    drawGrid();
                } else if (rows > 0 && grid[rows-1][columns].equals("k200")) {
                    grid[rows][columns] = "g";
                    rows--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a scissor");
                    keyValue = 200;
                    drawGrid();
                } else if (rows > 0 && grid[rows-1][columns].equals("k300")) {
                    grid[rows][columns] = "g";
                    rows--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a chainsaw");
                    keyValue = 300;
                    drawGrid();
                } else if (rows > 0 && grid[rows-1][columns].equals("b100") && keyValue != 100) {
                    JOptionPane.showMessageDialog(field, "you need a key to open this barricade");
                } else if (rows > 0 && grid[rows-1][columns].equals("b200") && keyValue != 200) {
                    JOptionPane.showMessageDialog(field, "you need a scissor to cut this bush");
                } else if (rows > 0 && grid[rows-1][columns].equals("b300") && keyValue != 300) {
                    JOptionPane.showMessageDialog(field, "you need a chainsaw to break this stump");
                } else if (rows > 0 && grid[rows-1][columns].equals("b100") || rows > 0 && grid[rows-1][columns].equals("b200") || rows > 0 && grid[rows-1][columns].equals("b300")) {
                    grid[rows][columns] = "g";
                    rows--;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else {
                    System.out.println("you can't go there");
                }
                break;

                //when down key is pressed
            case KeyEvent.VK_DOWN:
                if (rows < 9 && grid[rows+1][columns].equals("g")) {
                    grid[rows][columns] = "g";
                    rows++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else if (rows < 9 && grid[rows+1][columns].equals("f")) {
                    grid[rows][columns] = "g";
                    rows++;
                    grid[rows][columns] = "p" ;
                    drawGrid();
                    JOptionPane.showMessageDialog(field, "you win!");
                } else if (rows < 9 && grid[rows+1][columns].equals("k100")) {
                    grid[rows][columns] = "g";
                    rows++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a key");
                    keyValue = 100;
                    drawGrid();
                } else if (rows < 9 && grid[rows+1][columns].equals("k200")) {
                    grid[rows][columns] = "g";
                    rows++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a scissor");
                    keyValue = 200;
                    drawGrid();
                } else if (rows < 9 && grid[rows+1][columns].equals("k300")) {
                    grid[rows][columns] = "g";
                    rows++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    System.out.println("you found a chainsaw");
                    keyValue = 300;
                    drawGrid();
                } else if (rows < 9 && grid[rows+1][columns].equals("b100") && keyValue != 100) {
                    JOptionPane.showMessageDialog(field, "you need a key to open this barricade");
                } else if (rows < 9 && grid[rows+1][columns].equals("b200") && keyValue != 200) {
                    JOptionPane.showMessageDialog(field, "you need a scissor to cut this bush");
                } else if (rows < 9 && grid[rows+1][columns].equals("b300") && keyValue != 300) {
                    JOptionPane.showMessageDialog(field, "you need a chainsaw to break this stump");
                } else if (rows < 9 && grid[rows+1][columns].equals("b100") || rows < 9 && grid[rows+1][columns].equals("b200") || rows < 9 && grid[rows+1][columns].equals("b300")) {
                    grid[rows][columns] = "g";
                    rows++;
                    grid[rows][columns] = "p" ;
                    System.out.println(rows + ", " + columns);
                    drawGrid();
                } else {
                    System.out.println("you can't go there");
                }
                break;

            case KeyEvent.VK_R:
                rows = 0;
                columns = 0;
                keyValue = 0;
                grid = originalGrid;
                drawGrid();
                JOptionPane.showMessageDialog(field, "level has been reset");
                break;
        }
}
    public void keyReleased(KeyEvent e) {
        //no code here
    }
}