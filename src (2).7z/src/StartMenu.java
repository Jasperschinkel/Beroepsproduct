import javax.swing.*;
import java.awt.*;

public class StartMenu {

    private static final String title = "Test";
    private static final int width = 400;
    private static final int height = 400;

    private static JPanel upperPanel;
    private static JPanel panel;
    private static JButton start;
    private static JLabel instructions;
    private static JLabel movement;
    private static JLabel reset;


    public static void main(String[] args) {

        JFrame frame = new JFrame();
        frame.setSize(width, height);
        frame.setTitle(title);

        addComponents();
        frame.add(upperPanel, BorderLayout.NORTH);
        frame.add(panel, BorderLayout.CENTER);


        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private static void addComponents() { //todo finish this
        upperPanel = new JPanel();
        upperPanel.setLayout(new BorderLayout());
        panel = new JPanel();
        start = new JButton("start");
        instructions = new JLabel("instructions:");
        movement = new JLabel("move with the arrow keys");
        reset = new JLabel("press 'r' to reset the level");

        upperPanel.add(start);
        panel.add(instructions);
        panel.add(movement);

    }
}

 /*class menu {
    public  menu() {

    }
}*/